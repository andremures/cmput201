#ifndef FILEPRINT_H
#define FILEPRINT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "structs.h"

void fprint_instance(int m, int n, int t_1, int t_2, int ki, struct Job *jobs);

#endif
