// lpt and johnson functions
#ifndef LPT_H
#define LPT_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include "structs.h"

int lpt(struct Job* jobs, int left, int right, int m, int t);

#endif
