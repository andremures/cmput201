Assignment 3 Submission
  
submitting student: Andreea Muresan
ccid: amuresan
id: 1498868

other collaborators: James Hryniw
