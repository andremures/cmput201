// max and min funcitons
#ifndef COMPARE_H
#define COMPARE_H

int max(int a, int b);
int min(int a, int b);

#endif
