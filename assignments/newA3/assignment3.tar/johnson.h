// lpt and johnson functions
#ifndef JOHNSON_H
#define JOHNSON_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "structs.h"
#include "compare.h"

int johnson(struct Job* jobs, int left, int right, int t);

#endif
